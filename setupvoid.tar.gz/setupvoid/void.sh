#!/bin/bash

sudo xbps-install -Svy vim xf86-video-intel xorg-minimal xorg-fonts i3-gaps lxterminal viewnior feh polybar scrot git xrandr setxkbmap picom NetworkManager xz gcc xmodmap curl rofi  dbus telegram-desktop firefox lxappearance arc-theme arc-icon-theme

sudo ln -s /etc/sv/NetworkManager /var/service/ ; sudo ln -s /etc/sv/dbus /var/service/

git clone https://github.com/adi1090x/polybar-themes
./polybar-themes/setup.sh

curl -fLo ~/.vim/autoload/plug.vim --create-dirs     https://raw.githubusercontent.com/junegunn/vim-plug/master/plug.vim

mkdir -p ~/.config

sudo mkdir -p /etc/xdg/ ; sudo mv picom.conf /etc/xdg/
mv vimrc ~/.vimrc
mv xinitrc ~/.xinitrc
mv bashrc  ~/.bashrc
mv lxterminal ~/.config/
mv i3 ~/.config/
mv colors.ini ~/.config/polybar/cuts/
mv modules.ini ~/.config/polybar/cuts/
mkdir -p ~/Pictures;mv wallpaper1.jpg ~/Pictures


